sport_prediction <- function(x1,x2,x3,x4,x5,x6,x7,x8,x9) {

 Y = a + Xp3*x1 + Xp2*x2 + Xpa2 * x3 + Xppct2*x4 + Xft*x5 + Xfta*x6 + Xftpct*x7 + Xpa3 * x8 + Xppct3*x9
 return (Y)
}
pause = function()
{
    if (interactive())
    {
        invisible(readline(prompt = "Press <Enter> to continue..."))
    }
    else
    {
        cat("Press <Enter> to continue...")
        invisible(readLines(file("stdin"), 1))
    }
}
setwd("C:\\Python\\ReinforcementLearning\\TFAgents")
sports_data <- read.csv("sportsref_downloadR1.csv")
print(sports_data)
sports_data_input <- sports_data[, c("PTS", "P3","P2","PA2","PPCT2", "FT","FTA","FTPCT","PA3","PPCT3")] # 
print(head(sports_data_input))
# Create the relationship model.
model <- lm(PTS~P3+P2+PA2+PPCT2+FT+FTA+FTPCT+PA3+PPCT3, data = sports_data_input)
print(model)
cat("# # # # The Coefficient Values # # # ","\n")

a <- coef(model)[1]
print(a)
Xp3 <- coef(model)[2]
Xp2 <- coef(model)[3]
Xpa2 <- coef(model)[4]
Xppct2 <- coef(model)[5]
Xft <- coef(model)[6]
Xfta <- coef(model)[7]
Xftpct <- coef(model)[8]
Xpa3 <- coef(model)[9]
Xppct3 <- coef(model)[10]
print(Xp3)
print(Xp2)
print(Xpa2)
print(Xppct2)
print(Xft)
print(Xfta)
print(Xftpct)
print(Xpa3)
print(Xppct3)
install.packages("svDialogs")
library(svDialogs)
cat ("ENTER DATA FOR INPUT VARIABLES TO CALCULATE PREDICTION\n")

x1 <- dlgInput("P3 is ")$res
x1 <- as.numeric(x1)

x2 <- dlgInput("P2 is")$res

x2 <- as.numeric(x2)

x3 <-dlgInput("PA2 is")$res
x3 <-  as.numeric(x3)

x4 <- dlgInput("PPCT2 is")$res
x4 <- as.numeric(x4)

x5 <- dlgInput("FT  is")$res
x5 <- as.numeric(x5)

x6 <- dlgInput("FTA ->")$res
x6 <- as.numeric(x6)

x7 <- dlgInput("FTPCT ->")$res
x7 <- as.numeric(x7)

x8 <- dlgInput("PA3 ->")$res
x8 <- as.numeric(x8)

x9 <- dlgInput("PPCT3 ->")$res
x9 <- as.numeric(x9)
points <- sport_prediction(x1,x2,x3,x4,x5,x6,x7,x8,x9)

sprintf ("Results in %.1f points", points )